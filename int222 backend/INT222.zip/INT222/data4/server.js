const http = require('http');
const url = require('url');

const server = http.createServer((req, res) => {
  const urlObj = url.parse(req.url, true);
  const path = urlObj.pathname;

  if (path === '/') {
    // This is the home page, so return the HTML form
    res.setHeader('Content-Type', 'text/html');
    res.write('<html><body>');
    res.write('<h2>Enter a number to get its Fibonacci value:</h2>');
    res.write('<form action="/fibonacci" method="post">');
    res.write('<input type="text" name="number" required>');
    res.write('<input type="submit" value="Calculate">');
    res.write('</form>');
    res.write('</body></html>');
    res.end();
  } else if (path === '/fibonacci' && req.method === 'POST') {
    // This is the form submission page, so calculate the Fibonacci value
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const number = parseInt(body.split('=')[1]);
      const fib = fibonacci(number);
      res.setHeader('Content-Type', 'text/html');
      res.write('<html><body>');
      res.write(`<h2>The Fibonacci value of ${number} is ${fib}</h2>`);
      res.write('</body></html>');
      res.end();
    });
  } else {
    // This is an unknown page, so return a 404 error
    res.statusCode = 404;
    res.end('Error: Page not found');
  }
});

server.listen(3000, () => {
  console.log('Server listening on port 3000');
});

function fibonacci(n) {
  if (n === 0 || n === 1) {
    return n;
  } else {
    return fibonacci(n - 1) + fibonacci(n - 2);
  }
}