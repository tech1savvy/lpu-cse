// 06 Create a web server application with http module for the following scenario
//  a) Create a server node.js application using http module to find the nth Fibonacci number
//  b) Accept a number from the input text field of the client page and provide the output values as a response
//   with the click event on a button.

const http = require('http');
const url = require('url');

const fibonacci = (n) => {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

const server = http.createServer((req, res) => {
  const queryObject = url.parse(req.url, true).query;
  const n = parseInt(queryObject.n, 10);

  if (isNaN(n) || n < 0) {
    res.writeHead(400, {'Content-Type': 'text/plain'});
    res.end('Invalid input');
    return;
  }

  const result = fibonacci(n);

  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end(`The ${n}th Fibonacci number is ${result}`);
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});