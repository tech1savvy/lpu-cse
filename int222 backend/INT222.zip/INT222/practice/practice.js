// Q1 Implement an express application for the following
// a) Accept a number from the input text field of a user web page and perform the basic arithmetic
//operations, increment (++), decrement (--), and square, on the number inside a middleware function of server
// node.js application.
// b) Display the output values in the user web page as a response to the click event from the button.




// // Import required modules
// const express = require('express');
// const bodyParser = require('body-parser');

// // Create express application instance
// const app = express();

// // Set up middleware to parse request body
// app.use(bodyParser.urlencoded({ extended: true }));
 

// app.get('/', function(req, res) {
//     res.sendFile( __dirname + "/" + "practice.html" ); 
//   });


// // Define middleware function to perform arithmetic operations on input number
// const performArithmetic = (req, res, next) => {
//   const num = parseFloat(req.body.number);
 

//   // Check if input is valid number
//   if (isNaN(num)) {
//     res.status(400).send('Invalid input');
//     return;
//   }
  
//   // Perform arithmetic operations
//   req.number = num;
//   req.increment = num + 1;
//   req.decrement = num - 1;
//   req.square = num * num;
  
//   // Call next middleware function
//   next();
// };

// // Define route to display input and output values
// app.post('/calculate', performArithmetic, (req, res) => {
//   res.send(`
//     <h1>Arithmetic Operations</h1>
//     <p>Input Number: ${req.number}</p>
//     <p>Increment: ${req.increment}</p>
//     <p>Decrement: ${req.decrement}</p>
//     <p>Square: ${req.square}</p>
//   `);
// });

// // Set up server to listen on port 3000
// app.listen(3000, () => {
//   console.log('Server listening on port 3000');
// });