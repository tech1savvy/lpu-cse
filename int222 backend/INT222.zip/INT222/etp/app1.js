const express = require('express');
const fs = require('fs');
const app = express();

app.use(express.urlencoded({extended: true}));

const PORT = process.env.Port || 3000;

app.get('/', (req, res) => {
   res.send(`
   <form method="post" action="/submit">
   <label for="regno.">Registration no.:</label>
   <input type="text" id="regno." name="reg no."><br>
   <label for="Student Name."> Student Name:</label>
   <input type="text" id="studentname." name=" student name."><br>
   <label for="rollno.">Roll no.:</label>
   <input type="text" id="rollno." name="roll no."><br>
   <label for="mobileno.">Mobile no.:</label>
   <input type="text" id="mobileno." name="mobile no."><br>
   <label for="mailid.">mail id.:</label>
   <input type="text" id="mail id" name="mailid"><br>
   <button type="submit" >Submit</button>


   `);
});

app.post('/submit', (req, res) => {
    const { studentname, regNO, rollno, mobileno, mailid }
})


const data = 'Students Name' ${studentsname}

fs.appendFile('data.txt', data, (err) => {
       

    if (err) {
        console.log('error')}
        {
            else {
                console.log('Dta saved to file');
                res.send('Data sent successfully')
            }
        }
    }
    )



res.send('error')


app.listen(PORT, () => {
    console.log('Server is running on 3000')
});