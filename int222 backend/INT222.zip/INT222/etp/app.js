const express = require('express');
const http = require('http');

// Create an Express app
const app = express();

// Serve the client HTML file
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/client.html');
});

// Create a server that listens on port 3000
const server = http.createServer(app);

// Start the server
server.listen(3000, () => {
  console.log('Server running on port 3000');
});