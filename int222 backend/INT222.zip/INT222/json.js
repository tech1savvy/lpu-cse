// //object to json
// const details={
//     nam: 'raksha',
//     roll:52,
//     section:"KM032"
// }
// console.log(details.nam)
// const jsondata=JSON.stringify(details)
// console.log(jsondata)
// //if in the property name double quotes are there that means it's in json.
// //json to object
// const objdata=JSON.parse(jsondata)
// console.log(objdata)


const fs=require('fs')
const details={
        nam: 'raksha',
        roll:52,
        section:"KM032"
    }
    const jsondata=JSON.stringify(details)
fs.writeFile("json1.json",jsondata,(err)=>{
    console.log('done')
})
//read json file and convert back to obj(asynchronous method)
fs.readFile("json1.json",'utf-8',(err,data)=>{
    const out=JSON.parse(data)
    console.log(data)
    console.log(out)
})