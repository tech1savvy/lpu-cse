const fs = require('fs');
const { Writable } = require('stream');
const primeNumber = require('prime-number');

// Create a writable stream to write to the sample.txt file
const writableStream = fs.createWriteStream('sample.txt');

// Find prime numbers up to 100 and write them to the writable stream
for (let i = 2; i <= 100; i++) {
  if (primeNumber(i)) {
    writableStream.write(i + '\n');
  }
}

// End the writable stream and display "Task Completed" message in the console
writableStream.end(() => console.log("Task Completed"));