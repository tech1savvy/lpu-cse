// Q5 Create a web server application with the http module for the following scenario
// a) Create a server node.js application using http module to verify whether a number is prime or not. 
// b) Accept a number from the input text field of the client page and provide the output values as a 
// response with the click event on a button.

const http = require('http');

function isPrime(num) {
  for(let i = 2; i < num; i++)
    if(num % i === 0) return false;
  return num !== 1;
}

const server = http.createServer((req, res) => {
  if (req.url === '/' && req.method === 'GET') {
    res.setHeader('Content-Type', 'text/html');
    res.write('<html><body><form method="POST" action="/result"><label for="num">Enter a number:</label><input type="number" id="num" name="num"><br><button type="submit">Check Prime</button></form></body></html>');
    return res.end();
  }
  if (req.url === '/result' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const num = parseInt(body.split('=')[1]);
      const message = isPrime(num) ? `${num} is a prime number.` : `${num} is not a prime number.`;
      res.setHeader('Content-Type', 'text/html');
      res.write(`<html><body><p>${message}</p></body></html>`);
      return res.end();
    });
  }
});

server.listen(3000);
console.log('Server running at http://localhost:3000/');