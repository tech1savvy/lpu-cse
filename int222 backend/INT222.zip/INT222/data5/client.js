const net = require('net');

const client = new net.Socket();

client.connect(3000, 'localhost', () => {
  console.log('Connected to server');
  const studentDetails = {
    name: 'John Doe',
    age: 22,
    gender: 'Male',
    email: 'johndoe@example.com',
    phone: '1234567890'
  };
  client.write(JSON.stringify(studentDetails));
});

client.on('data', (data) => {
  console.log(`Received message from server: ${data.toString()}`);
  client.end();
});

client.on('close', () => {
  console.log('Connection closed');
});