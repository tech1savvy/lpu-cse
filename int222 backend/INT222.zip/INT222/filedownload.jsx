var express =require('express');
var app=express();
app.get('/',function(req,res){
res.sendFile(__dirname + "/" + "filedownload1.html");
})
app.get('/down',function(req,res){
res.download('filedownload.txt',function(err){
if(err){console.error("No such file is found");}
else{console.error("file is dowloaded");}
});
});
app.listen(2006,function(err){
if(err) {console.error(err);}
else{console.error("server started");}
});