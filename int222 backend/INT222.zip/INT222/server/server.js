// const http=require('http')// if we are creating a server we need port no. (any unused port no.) and local host address()
// //for creating a server we have to import a module
// const url=require('url')// we are going to fetch the url
// const server=http.createServer((req,res)=>{//two diff parameter(req: to request for website and res: to response over there)
//     // console.log(req,url)

//     if(req.url=='/')
//     {
//      res.end("response getting from contact page")//call back function
//     }
//     else if(req.url =='/contact'){
//         res.end("response getting from contact page")
//     }
//     else if(req.url =='/about'){
//         res.end("response getting from about page")
//     } else{res.end('not found')}
//     //res.end("getting response")//call back function
//     })
// server.listen(8000,"127.0.0.1"),()=>{//any freee port no. and local address
//     console.log("listening");
// }

//reading from file and displaying on server
const http=require("http")
const url=require('url')
const fs=require("fs")
const server=http.createServer();
server.on('request',(req,res)=>
{
const fs=require("fs")
fs.readFile(("input.txt"),(err,data)=>{
if(err)return console.error(err)
res.end(data.toString())
})
})

server.listen(8000,"127.0.0.1")