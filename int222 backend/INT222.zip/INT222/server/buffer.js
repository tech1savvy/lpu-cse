// var buf=Buffer.alloc(10)
// buf.write("hello")
// console.log(buf)
// console.log(buf.toString())

// //other way to create
// var buf2=Buffer.from("welcome")
// console.log(buf2)

// //fill method
// var buf3=Buffer.alloc(5)
// console.log(buf3.fill('a'))//same value will be filled 5 times in the buffer
// console.log(buf3.toString())

//create two buffers and concatenate them using .concatenate

// var buf1 = Buffer.from("Good");
// var buf2 = Buffer.from("morning");

// var list = [buf1, buf2];
// var newbuff = Buffer.concat(list);

// console.log("The concatenated buffer:");
// console.log(newbuff);
// console.log(newbuff.toString())

// //compare two buffers
// var buf1 = Buffer.from('abc');
// var buf2 = Buffer.from('abc');
// var x = Buffer.compare(buf1, buf2);
// console.log(x);

//copy the content of one buffer to another buffer
var buf1 = Buffer.from('abcdeghyvjhbj');
var buf2 = Buffer.from('HELLO');

buf2.copy(buf1, 5);

console.log(buf1.toString());