// let sum=0
// let n=prompt("enter the number n")
// n=Number.parseInt(n)
// for(let i=0;i<n;i++)
// {
//     sum +=(i+1)
//     console.log((i+1),"+")
//     console.log("sum of first" + n + "natural no. is" + sum)
// }
// what is the diff between console of js and console of node js
// diff b/w null and undefined data types
// diff b/w symbol and string
//diff b/w a method and a function
//with delete operator it removes the element but still it shows the same length why?
// let obj={
//     raksha:1800000,
//     isha:180000,
//     battuk:2100000,
// }
// for(let a in obj)
// {
//     console.log("$" + obj[a])
// }
// const var1="hello"
// for(let i in var1)
// {
//     console.log(var1[i])
// }
// let sum=0;
// let n=parseInt(prompt("enter the number:"))
// while(n>=0){
// sum+=n
// n=parseInt(prompt('enter a number'))
// }
// console.log(`the sum is ${sum}`)
//perform a sum untill n is negative given by the user
// var sum=0;

// do{
// var n=Number.parseInt(prompt("enter the value of n"));
// if(n>=0)
// sum+=n;
// else
// break;
// }while(n>=0);
// console.log(sum)

/*-------------------------------------------------*/
// function avg(x,y)
// {
//     return (x+y)/2
// }
// let a=10
// let b=20
// let c=30
// console.log("Average of a and b is",avg(a,b))
// console.log("Average of b and c is",avg(a,b))
// console.log("Average of a and c is",avg(a,b))
/*-------------------non-parameterized function-----*/
// function hello(){
//     console.log("hello world")
//     }
//     hello();
//     hello();
/*----------------------arrow function-----------*/
// const sum=(p,q)=>
// {
//     return p+q
// }
// console.log(sum(9,7))

/*----------------------non-parameterized arrow function-----------*/
// function hello(){
//     console.log("hello world")
//     }
//     const sum=(p,q)=>
//     {
//     return p+q
//     }
//     arrow=()=>
//     {
//     console.log("i am a non parameterized arrow function")
//     }
//     console.log(sum(9,7))
//     hello();
//     hello();
//     arrow();

/*---------------template literals------------------*/
// let a="raksha"
// let b="KM032"
// let c=`${a} studies in ${b}`
// console.log(c)

//string interpolation:- we can directly add the variables into string