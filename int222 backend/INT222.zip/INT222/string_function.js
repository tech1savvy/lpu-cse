// let a="rakshayadav"
// let length =a.length;
// let part=a.slice(2,7);
// let substring=a.substring(2,7);
// let text2=a.toUpperCase();
// let trim=a.trim()
// console.log(length + "," + part + ","+ substring+","+ text2+","+trim)

//extract the number from the given string
// let new1 = "this session id is 2001"
// let new2 = Number.parseInt(new1.slice(19))
// console.log(new2)

// let course=["CSE211", 23, "INT222", 34]
// console.log(course[2])
// console.log("length of given array",course.length)
// console.log[3]=21//adding a value
// console.log[0]=18//changing a value
//print the elements of array using a for loop
// let age=[1,2,3,4,5]
// for(let i=0;i<age.length;i++)
// {
//     const a=age[i]
//     console.log(a)
//}
//arrays are objects(their index number are their keys)
//array methods: slice, concat, reverse, sort, push, shift, join, map, filter
//array methods modify as well as create new array.
//string are mutable and symbols and arrays are immutble
//toString convert the array into a string.
//join joins two diff string using any separator
//join modifies an array
//delete is not a method, it's a operator and it's purpose is 
//slice and splice takes how many arguments?
//splice is used to add a new element in array,it modifies the array whereas slice creates a new one.
//purpose of arrayfrom: if we have to make an array from an object then we take help of array from,
//E.g. if we are having html collection and we want to fetch that into array 
//so we can't directly fetch so we'll have to convert it firstly then we use array from,
//string into an array
//map and for each do the same job but for each loop modify the array but map creates a new array.
//sort is used to sort the array alphabetically not in ascending or descending order, 
//to sort in asc. or des. we use function compare function
//purpose of for in: to access or extract the objects from string.

// let age=[1,2,3,4]
// let b=age.toString()
// console.log(b,typeof b)
// let c=age.join("*")
// console.log(c,typeof c)
// let r=age.pop()//remove and it will change the array
// console.log(age,r)//return the poped element
// let re=age.push(34)//add and it will change the array
// console.log(age,re)//returns the length of array
// let ree=age.shift()//removes from the start i.e the 0th index value
// console.log(ree,age)//returns the array and its length
// let reee=age.unshift(5)//add from the start i.e the 0th index value
// console.log(reee,age)//returns the array and its length


// let age=[1,2,3,4]
// console.log(age.length)
// delete age[0]
// console.log(age.length)

// let age=[1,2,3,4]
// let newage=[5,6,7,8]
// let a=age.concat(newage)
// console.log(a)

// let compare=(a,b)=>{
//     return a-b
// }

// let age=[91,11121,1131,4]
// age.sort(compare)
// console.log(age)

// const age=[21,41,56,78,6,5]
// let del=age.splice(2,1,23,34,68)//returns the deleted element and modifies it
// console.log(del)
// console.log(age)
// let newage=age.slice(3)//will create a new array doesn't modify
// console.log(newage)

// let a=[2,3,4,5,6]
// a.forEach((data)=> //iterated an arrow function
// {
//     console.log(data*data)
// })

//pass one string and fetch it in form of array

// let a=[2,3,4,5,6]
// for(let item of nam)//shortcut to access array element(for of loop)returns element
// {
//     console.log(item)
// }
// for(let i in nam)//(for in loop)return index of elements
// {
//     console.log(i)
// }

//perform some operation on existing element of array foreach
// let nam=[2,4,6,7]
// let a=nam.map((value)=>{//create new array by performing
//     console.log(value)
//     return value+1     
// })
// console.log(a)
// console.log(nam)

//filter also creates a new array
//filter an array with values to pass  test
// let arr=[32,25,67,6,9,15]
// let arr1=arr.filter((a)=>{
//     return a<10
// })
// console.log(arr1)
// console.log(arr)//will not modify the original array

//purpose of reduce method: reduce the array to a single value.
// let arr=[1,2,3,4,5,6]
// let a =arr.reduce((i1,i2)=>{
//     return i1+i2
// })
// console.log(a)

//use reduce to calculate the factorial of given numbers in array of first n natural number
//(n being the number whose factorial needs to be calculated)

// const n = 5; // calculate factorial of first 5 natural numbers
// const naturalNumbers = Array.from({ length: n }, (_, i) => i + 1); // create an array of the first n natural numbers
// const factorials = naturalNumbers.reduce((acc, curr) => acc * curr, 1); // calculate the factorials using reduce

// console.log(factorials); // output: 120
// In the code above, we first define n as the number of natural numbers we want to calculate the factorials of.
// We then create an array of the first n natural numbers using Array.from() and
//  length and map the array to add 1 to each index so that the array contains the numbers 1 to n.

// Finally, we use reduce() to multiply all of the numbers in the array together to calculate the factorials.
//  We pass reduce() a callback function that multiplies the accumulator (acc)
//   by the current value (curr) for each element in the array.
//    We set the initial value of the accumulator to 1 since 1 is the identity element for multiplication.


// The output of the code will be the factorial of n, which in this case is 120 (i.e., 1 * 2 * 3 * 4 * 5).
// setInterval(function(){
//     alert("Hi Raksha!")
// },1000)
// const sum=(a,b)=>{
//     console.log("the function is sum"+(a+b));
// }
// setInterval(sum,2000,2,3)
//write a script to print hello after every 1s and after 5
//times it should print done(execute using setinterval)hint(clear interval used)

// let counter=0
// const a=setInterval(()=>{
//     console.log("HI Raksha!")
//     counter +=1
//     if(counter==5)
//     {
//         console.log("done")
//         clearInterval(a)
//     }
// },1000)

// let count=1
// let num=11
// const a=setInterval(()=>{
//     console.log(`${num} * ${count} = ${count*num}`)
//     count+=1
//     if(count==11){
//         clearInterval(a)
//     }
// },1000)
















