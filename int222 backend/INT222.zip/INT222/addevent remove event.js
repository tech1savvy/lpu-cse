// <!-- when function reference is same then only remove event listener will work
// <!DOCTYPE html>
// <html lang="en">
// <head>
// <meta charset="UTF-8">
// <meta http-equiv="X-UA-Compatible" content="IE=edge">
// <meta name="viewport" content="width=device-width, initial-scale=1.0">
// <title>Document</title>
// </head>
// <body>
// <p>After clicking on button the button will get disable...!</p>
// <button id='btn' onclick='disableBtn()'>Click Me</button>

// <p id="demo"></p>

// <script>
// function disableBtn(){
// document.getElementById("demo").innerHTML = "Hello World";
// document.getElementById('btn').disabled = true;
// } -->

//  let x=function(e) //e is event object gives us pointer events
//  {
//     alert("content 1")
//  }
//  let y=function(e)
//  {
//     alert("another content")
//  }

//  btn.addEventsListener('click',x)
//  btn.addEventListener('click',y)
//  let a=prompt("enter number")
//  if(a=="2")
//  {
//     btn.removeListener('click',y)
//  }

// setTimeout(()=>{
//     console.log("chapter 1")
// },1000)
// try {
//     console.log(hello)
// }
// catch(error)//error object
// {   
//      console.log(error.name)//property of error object
//      console.log(error.message)//property of error object
// }
// setTimeout(()=>{
//     console.log("chapter 2")
// },2000)
// setTimeout(()=>{
//     console.log("chapter 3")
// },3000)

// try{
//     console.log("running")
// }
// catch(err)
// {
//     console.log("error is there")
//     console.log(p)
// }
// finally{
//     console.log("code is still running")
// }

// try{
//     let age=prompt("enter age")
//     age=Number.parseInt(age)
//     if(age>150)
//     {
//         throw new ReferenceError("this is not true")
//     }
// }
// catch(err){
//     console.log(err.name)
//     console.log(err.message)
// }



