var prompt = require('prompt');
//FUnction call
prompt.start();

//Reading two properties from user i.e name & class
prompt.get(['Name','class'], function (err, r) {

    //Printing the result
    console.log('Command-line input received:');
    console.log('Name : '+ result.Name);
    console.log('class: '+ result.class);
})