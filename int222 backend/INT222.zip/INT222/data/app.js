// 02 Create an express application for the following scenario 
// a) Create a text file and add student information (Reg. No., Name, Grade) in the server system.
//  b) Accept a file name from the input text field of a user web page and transfer the requested file 
//  using sendFile() function from the server as a response to the button click event from the user web page
 



// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

// Create express application instance
const app = express();

// Set up middleware to parse request body
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from public folder
app.use(express.static(path.join(__dirname, 'public')));

 app.get('/', function(req, res) {
     res.sendFile( __dirname + "/" + "index.html" );  
   });

// Set up route to transfer requested file
app.post('/download', (req, res) => {
  const fileName = req.body.fileName;
const filePath = path.join(__dirname, fileName);

res.sendFile(filePath);
});

// Set up server to listen on port 3000
app.listen(3000, () => {
  console.log('Server listening on port 3000');
});