// Q4 Create an express application with the following requirements
// a) Accept Student Name, Reg. no., Roll. No., Mobile No. and Mail Id from the input text fields of a client
// page and perform chain of validations on the data using the express-validator module in the server
// application.
// b) Check all the fields are not empty, minimum and maximum lengths of data.
// c) Add a submit button on the client web page to submit the data and display the warning messages if required.

const express = require('express');
const { body, validationResult } = require('express-validator');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
  res.render('index', { errors: null });
});

app.post('/', [
  body('name').notEmpty().withMessage('Name is required'),
  body('regNo').notEmpty().withMessage('Registration number is required'),
  body('rollNo').notEmpty().withMessage('Roll number is required'),
  body('mobileNo').notEmpty().withMessage('Mobile number is required')
    .isMobilePhone().withMessage('Invalid mobile number'),
  body('email').notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Invalid email address')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('index', { errors: errors.array() });
  } else {
    const { name, regNo, rollNo, mobileNo, email } = req.body;
    // do something with the validated data
    res.send('Data successfully submitted!');
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});