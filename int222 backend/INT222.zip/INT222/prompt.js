// var prompt = require('prompt');
// //FUnction call
// prompt.start();

// //Reading two properties from user i.e name & class
// prompt.get(['Name','class'], function (err, result) {

//     //Printing the result
//     console.log('Command-line input received:');
//     console.log('Name : '+ result.Name);
//     console.log('class: '+ result.class);
// })

//Find the sum of all positive no's until the user gives negative no. using prompt
const prompt = require('prompt-sync')();
let sum=0
let number=parseInt(prompt('enter a number'))
while(number>0){
sum+=number
number=parseInt(prompt('enter a number'))
}
console.log(`the sum is ${sum}`)