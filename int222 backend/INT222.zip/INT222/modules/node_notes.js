// REPL is a fetaure inside node js
// Read Evaluate Print Loop
// we have to enter into repl environment to execute node
// node enter to enter
// .exit enter to exit
// cls to clear
// type nul > filename.js (this is to create empty file outside the environment) in node
// directly expression can work
// variable can be declared
// Multiline code
// _(underscore) if we want to fetch previous data
// Editor mode .editor to enter the editor mode
// ctrl+c the cancel the program
// ctrl+d to finish 
// .exit to come out from the editor mode
// node.js is asynchronous as if one file is not loading it'll shift to another.
// const fs=require('fs')
// fs.writeFileSync('hut.txt','huts')//to append content
// fs.writeFileSync('read.txt','first module')
// fs.appendFileSync('read.txt',' in nodejs')
// try {
//     fs.copyFileSync('read.txt','read1.txt')
// }
// catch(err){
//     console.log('one file doesnt exist');
// }
// fs.rmSync("read1.txt")
// Asynchronous functions below ones 
// writeFile is asynchronous in nature and it carries three parameters (file name,content,arrow function)
// fs.writeFile('test.txt','new content',(err)=>{
//     console.log("task done")
// })
// fs.appendFile('test.txt','write me',()=>{
//     console.log("task done")
// })
// fs.readFile('test.txt','utf-8',(err,data)=>{
//     console.log(data)
// })
// fs.copyFile('test.txt','new text',function(err){
//     if(err)return console.log('no file')
//     console.log('task completed')
// })
// fs.unlink('test1.txt',(err)=>{
//     console.log("deleted")
// })
// const data=fs.readFileSync('read.txt','utf-8')
// console.log(data)
// console.log('after the data')

//os module
// const os=require('os')
// console.log(os.arch())
// console.log(os.hostname())
// console.log(os.platform())
// console.log(os.tmpdir())//temporary directory
// console.log(os.type())

//path module
// const path=require('path')
// console.log(path.parse('c:\Users\raksh\OneDrive\Desktop\INT222\node_notes.js'))
// const my path=path.parse('c:\Users\raksh\OneDrive\Desktop\INT222\node_notes.js')
// console.log(mypath.name)

//https module
const add=(a,b)=>{
    return a+b;
}
const sub=(a,b)=>{
    return a-b;
}
const mul=(a,b)=>{
    return a*b;
}
const name="raksha";
module.exports={add,sub,mul,name}//object destructuring: we can call all the functions in one go
//alice method
//module.exports.add=add;//first add is an alice then we are denoting the function add
//module.exports.sub=sub;
//module.exports.name=name;
//module.exports.mul=mul;