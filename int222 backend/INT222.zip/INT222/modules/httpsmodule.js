// const add=require("./node_notes.js")
const {add,sub,mul,name}=require("./node_notes.js")
console.log(add(5,5));
console.log(sub(5,5));
console.log(mul(5,5));
// const name=require("./node_notes.js")
console.log(name);