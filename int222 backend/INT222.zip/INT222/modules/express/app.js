// npm init, npm init -y in this alt details will be filled automatically
// by using express we create API
//we use some methods like get(read) post(create new data i.e. write) put(update) delete, 
//these are the crude operation
// const express=require('express')
// const app=express()//utilize the function so that it can fetch all the rquired modules automatically
// app.get("/",(req,res)=>{//("/" mean current directory)
//     res.send("welcome to Raksha's worldz")
// })
// app.listen(8000,()=>{//port no. and then call back function
//     console.log("listening to port")
// })

//----------------------------------------------------------------

// const express=require('express')
// const app=express()
// app.get("/",(req,res)=>{
// res.send("Welcome to express")
// })
// app.get("/feedback",(req,res)=>{
//     res.send("welcome to feedback")
// })
// app.get("/about",(req,res)=>{
//     res.send("welcome to about")
// })
// app.listen(8000,()=>{
//     console.log("listening")
// })

//---------------------------------------------------

const express=require('express')
const app=express()
//passing html content
app.get("/",(req,res)=>{
res.write("<h1>Welcome<h1>")
req.write
})