const app = require('express')();
const http = require('http').Server(app)
const io = require('socket.io')(http)
app.get('/', function(req, res){
res.sendFile(__dirname + '/socket1.html')
});
//Whenever someone connects this gets executed
//connection event
io.on('connection', function(socket){
console.log('A user connected'+ socket.id);
//sending message after sometime so we will use set timeout function
setTimeout(function(){
socket.send('message send and will s=display after 1 sec')
},1000)
//Whenever someone disconnects this piece of code executed
//disconnection event
socket.on('disconnect', function () {
console.log('A user disconnected');
});
});
http.listen(3001, function(){
console.log('listening on 3001');
});
