const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
app.use(cookieParser());

app.get('/', (req, res) => {
  // Set the cookie with the name 'myCookie' and value 'Hello, World!'
  res.cookie('myCookie', 'Hello, World!');

  res.send(`
    <html>
      <body>
        <h1>Cookie Information:</h1>
        <div id="cookie-info"></div>
        <button onclick="showCookie()">Show Cookie</button>
        <button onclick="resetCookie()">Reset Cookie</button>

        <script>
          function showCookie() {
            const cookieInfo = document.getElementById('cookie-info');
            cookieInfo.innerHTML = "Value: " + document.cookie;
          }

          function resetCookie() {
            document.cookie = "myCookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            const cookieInfo = document.getElementById('cookie-info');
            cookieInfo.innerHTML = "Value: Cookie reset!";
          }
        </script>
      </body>
    </html>
  `);
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
