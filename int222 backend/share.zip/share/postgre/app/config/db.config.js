
module.exports = {
    HOST: "localhost",
    USER: "postgres",
    PASSWORD: "Arwinder94#",
    DB: "maindatabase",
    dialect: "postgres",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };

 // type nul > db.config.js

